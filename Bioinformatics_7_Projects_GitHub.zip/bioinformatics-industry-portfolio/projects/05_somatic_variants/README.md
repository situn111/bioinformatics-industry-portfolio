# Tumour–normal somatic variants

**Area:** Cancer genomics / paired DNA  
**Status:** implemented research/portfolio starter; external-tool runs not end-to-end validated in this delivery.

## Pipeline

Prepared paired BAMs → Mutect2 → orientation model → matched contamination → FilterMutectCalls → PASS VCF

## Question this project addresses

Which tumour-specific SNVs and small indels remain after matched-normal and artifact filtering?

## Setup and run

Run all commands from the repository root on Linux or Ubuntu under WSL2.

```bash
conda env create -f projects/05_somatic_variants/environment.yml
conda activate 05_somatic_variants
python projects/05_somatic_variants/pipeline.py --config projects/05_somatic_variants/config.example.json
# Edit a COPY of config.example.json; inspect the plan before execution.
python projects/05_somatic_variants/pipeline.py --config path/to/your_config.json --execute
```

Without `--execute`, the script produces a plan and does not launch scientific tools. A plan is not input-file or scientific validation. Config paths are resolved relative to your current directory (use the repository root). Execution requires a new/empty output directory. There is no silent resume; use a new run ID after fixing failures.

The environment files pin selected major/minor versions as baseline constraints. They are not solved lockfiles and were not installed here. Resolve them on your platform, run validation, then capture exact package builds with `tools/environment_snapshot.sh`.

## Inputs and preparation

Use aligned, coordinate-sorted, duplicate-marked, base-recalibrated and indexed tumour and matched-normal BAMs. Use project 04 preprocessing logic for each sample; do not use its germline call output as somatic input. The normal sample name must exactly match the normal BAM `@RG SM` tag; tumour and normal must be distinct and correctly paired.

Provide the same reference assembly plus `.fai` and dictionary, an AF-only population germline resource, a technology-matched panel of normals, and a common biallelic SNP resource appropriate for GetPileupSummaries. VCF resources must be bgzip compressed and indexed. BAM indices must be available. A sample sheet and identity checks are required before scaling to multiple patients.

## Outputs

Unfiltered and filtered VCFs; F1R2 orientation priors; pileup tables; contamination and segmentation estimates; PASS VCF; variant statistics; logs

## Validation and interpretation

Evaluate against truth mixtures/reference materials across variant allele fraction and coverage strata. Review tumour purity, normal contamination, contamination estimates, sample swaps, orientation artifacts, strand bias and allele support. Validate clinically important calls orthogonally through the appropriate laboratory process.

This is a paired SNV/indel research workflow. It does not call somatic CNVs, structural variants, MSI, HRD or actionable treatments. It deliberately does not calculate TMB: that requires a validated callable territory denominator and defined filtering policy. PASS variants still require annotation and expert review. Use the optional VEP script separately; drug associations require current, licensed evidence sources.

## Resource planning

8–32 CPU cores, 32–64+ GB RAM; substantial BAM/VCF scratch. Whole-genome tumour/normal analysis can take many hours or longer.

## Reproducibility record

Keep the edited configuration, input checksums, reference/database versions, exact environment export, command logs, code commit, QC decisions and final reports together. Commands for checksum generation are in `tools/hash_inputs.py`. See `docs/VALIDATION.md` and `docs/TEST_REPORT.md` for what was and was not tested.

## Primary documentation

- https://gatk.broadinstitute.org/hc/en-us/articles/360035531132--How-to-Call-somatic-mutations-using-GATK4-Mutect2
- https://github.com/broadinstitute/gatk/blob/master/docs/mutect/mutect.tex
