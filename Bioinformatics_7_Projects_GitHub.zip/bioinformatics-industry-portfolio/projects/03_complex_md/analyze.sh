#!/usr/bin/env bash
set -euo pipefail
# Run from repository root; supply a curated index with Protein_Ligand, System,
# Backbone, C-alpha and Ligand groups. Verify group names and selections first.
run=${1:?Usage: bash analyze.sh results/03_md curated.ndx}
index=${2:?Provide curated index}
printf 'Protein_Ligand\nSystem\n' | gmx trjconv -s "$run/production.tpr" -f "$run/production.xtc" -n "$index" -pbc mol -center -o "$run/centered.xtc"
printf 'Backbone\nSystem\n' | gmx trjconv -s "$run/production.tpr" -f "$run/centered.xtc" -n "$index" -fit rot+trans -o "$run/aligned.xtc"
printf 'Backbone\nBackbone\n' | gmx rms -s "$run/production.tpr" -f "$run/centered.xtc" -n "$index" -o "$run/backbone_rmsd.xvg" -tu ns
# Fit protein backbone, then measure ligand RMSD: do not fit the ligand to itself.
printf 'Backbone\nLigand\n' | gmx rms -s "$run/production.tpr" -f "$run/centered.xtc" -n "$index" -o "$run/ligand_rmsd.xvg" -tu ns
printf 'C-alpha\n' | gmx rmsf -s "$run/production.tpr" -f "$run/aligned.xtc" -n "$index" -o "$run/rmsf.xvg" -res -nofit
