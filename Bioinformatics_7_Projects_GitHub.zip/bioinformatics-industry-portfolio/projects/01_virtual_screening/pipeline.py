"""Prepared receptor + SMILES -> 3D ligand preparation -> Vina -> ranked scores."""
import sys,json,csv,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from common.runner import load,file_input,output_dir,identifier

def main():
    a,c=load()
    for key in ('center','size'):
        if len(c[key])!=3 or not all(isinstance(x,(float,int)) and math.isfinite(x) for x in c[key]):
            raise ValueError('center and size require three finite numbers')
    if min(c['size'])<=0:raise ValueError('Box sizes must be positive')
    if not c.get('box_validated',False) and a.execute:
        raise ValueError('Set box_validated=true after locating the binding site; example coordinates are not a target.')
    if not a.execute:
        print(json.dumps({'mode':'PLAN_ONLY','workflow':['validate receptor / box','RDKit ETKDG conformer','Meeko PDBQT','Vina docking','rank and export'],'config':c},indent=2));return
    from rdkit import Chem
    from rdkit.Chem import AllChem
    from meeko import MoleculePreparation,PDBQTWriterLegacy
    from vina import Vina
    receptor=file_input(c['receptor']);ligands=file_input(c['ligands_csv'])
    with ligands.open(newline='') as f:
        rows=list(csv.DictReader(f))
    ids=[identifier(r['id']) for r in rows]
    if len(ids)!=len(set(ids)):raise ValueError('Duplicate ligand IDs')
    out=output_dir(c['out']);results=[];failed=[]
    for row in rows:
        name=row['id']
        try:
            m=Chem.MolFromSmiles(row['smiles'])
            if m is None or len(Chem.GetMolFrags(m))!=1:raise ValueError('Require one valid, curated molecular species')
            if Chem.FindMolChiralCenters(m,includeUnassigned=True) and any(t=='?' for _,t in Chem.FindMolChiralCenters(m,includeUnassigned=True)):
                raise ValueError('Unspecified stereochemistry; enumerate/curate before screening')
            m=Chem.AddHs(m);params=AllChem.ETKDGv3();params.randomSeed=int(c['seed'])
            if AllChem.EmbedMolecule(m,params)!=0:raise ValueError('Embedding failed')
            if not AllChem.MMFFHasAllMoleculeParams(m):raise ValueError('MMFF parameters unavailable')
            if AllChem.MMFFOptimizeMolecule(m,maxIters=1000)!=0:raise ValueError('MMFF optimization did not converge')
            setups=MoleculePreparation().prepare(m)
            if len(setups)!=1:raise ValueError('Unexpected preparation multiplicity')
            pdbqt,ok,error=PDBQTWriterLegacy.write_string(setups[0])
            if not ok:raise ValueError(error)
            (out/f'{name}.pdbqt').write_text(pdbqt)
            v=Vina(sf_name='vina',cpu=int(c['cpu']),seed=int(c['seed']))
            v.set_receptor(str(receptor));v.set_ligand_from_string(pdbqt)
            v.compute_vina_maps(center=c['center'],box_size=c['size'])
            v.dock(exhaustiveness=int(c['exhaustiveness']),n_poses=int(c['poses']))
            v.write_poses(str(out/f'{name}_poses.pdbqt'),n_poses=int(c['poses']),overwrite=False)
            energy=float(v.energies(n_poses=1)[0][0])
            results.append({'id':name,'smiles':row['smiles'],'vina_kcal_mol':energy})
        except Exception as e:failed.append({'id':name,'error':str(e)})
    with (out/'ranking.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['id','smiles','vina_kcal_mol']);w.writeheader();w.writerows(sorted(results,key=lambda r:r['vina_kcal_mol']))
    (out/'failures.json').write_text(json.dumps(failed,indent=2))
    (out/'run_config.json').write_text(json.dumps(c,indent=2))
    if failed:raise RuntimeError(f'{len(failed)} ligands failed. Partial outputs are retained; inspect failures.json.')
if __name__=='__main__':main()
