"""Usage: python tools/hash_inputs.py data/file1 data/file2 > inputs.sha256"""
import hashlib,sys
from pathlib import Path
for name in sys.argv[1:]:
    h=hashlib.sha256()
    with open(name,'rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    print(h.hexdigest(),Path(name))
