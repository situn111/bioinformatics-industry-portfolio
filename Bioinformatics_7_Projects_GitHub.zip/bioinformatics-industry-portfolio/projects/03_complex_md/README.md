# Protein–ligand molecular dynamics

**Area:** Drug discovery / molecular simulation  
**Status:** implemented research/portfolio starter; external-tool runs not end-to-end validated in this delivery.

## Pipeline

Reviewed prepared complex → minimization → NVT → NPT → production → protein/ligand RMSD, RMSF and thermodynamic QC

## Question this project addresses

How does a prepared protein–ligand complex behave under a defined simulation model?

## Setup and run

Run all commands from the repository root on Linux or Ubuntu under WSL2.

```bash
conda env create -f projects/03_complex_md/environment.yml
conda activate 03_complex_md
python projects/03_complex_md/pipeline.py --config projects/03_complex_md/config.example.json
# Edit a COPY of config.example.json; inspect the plan before execution.
python projects/03_complex_md/pipeline.py --config path/to/your_config.json --execute
```

Without `--execute`, the script produces a plan and does not launch scientific tools. A plan is not input-file or scientific validation. Config paths are resolved relative to your current directory (use the repository root). Execution requires a new/empty output directory. There is no silent resume; use a new run ID after fixing failures.

The environment files pin selected major/minor versions as baseline constraints. They are not solved lockfiles and were not installed here. Resolve them on your platform, run validation, then capture exact package builds with `tools/environment_snapshot.sh`.

## Inputs and preparation

The input directory must contain `solvated_ions.gro`, `topol.top` and all included `.itp`/restraint files. Prepare a solvated, ionized protein–ligand system with compatible protein/ligand force fields and water model. Review atom ordering, ligand charge, topology, periodic box, ionic strength and restraint groups.

Set `preparation_reviewed=true` only after review. Example MDPs use generic PME and cutoff settings and are NOT universal: change cutoffs, dispersion corrections and constraints to match the chosen force field. The examples use one system thermostat group for simplicity. NVT and NPT use `-DPOSRES`; the topology must implement the intended restraints.

Example durations are 100 ps NVT, 100 ps NPT and 1 ns production. These are starter values, not evidence of equilibration or convergence. `mdrun -nt` targets thread-MPI builds; change the launcher for MPI/HPC installations.

## Outputs

EM/NVT/NPT/production GRO, TPR, EDR, CPT, logs; production XTC; temperature.xvg; density.xvg; optional RMSD/RMSF XVG

## Validation and interpretation

Inspect minimization convergence, energy, temperature, density, pressure behavior, constraint warnings and periodic-boundary treatment. Never use `-maxwarn` to force an unexplained topology through. Use multiple independent production replicas, convergence analysis and appropriate simulation durations for the question.

After reviewing index groups, run `bash projects/03_complex_md/analyze.sh results/03_md path/to/curated.ndx`. The ligand RMSD is measured after fitting the protein backbone. Large ligand RMSD can include symmetry effects and requires inspection. RMSD stability alone does not establish binding or efficacy. No MM/PBSA, free-energy perturbation or binding-energy claim is implemented.

Before repeating runs, use separate output directories and independent velocity seeds; the supplied example uses seed 42.

## Resource planning

8+ CPU cores; GPU-enabled GROMACS recommended for larger systems. RAM and storage depend on atom count, trajectory frequency and run length.

## Reproducibility record

Keep the edited configuration, input checksums, reference/database versions, exact environment export, command logs, code commit, QC decisions and final reports together. Commands for checksum generation are in `tools/hash_inputs.py`. See `docs/VALIDATION.md` and `docs/TEST_REPORT.md` for what was and was not tested.

## Primary documentation

- https://manual.gromacs.org/current/user-guide/
- https://manual.gromacs.org/current/user-guide/mdp-options.html
