import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from common.runner import load,execute,command,identifier

def build(c):

    o=Path(c['out']);base=Path(c['prepared_dir']);gmx=c.get('gmx','gmx');nt=str(c['threads'])
    if not c.get('preparation_reviewed',False):
        # Plan allowed, execution guarded in entry point below.
        pass
    steps=[];inputs=[str(base/'solvated_ions.gro'),str(base/'topol.top')]
    previous=base/'solvated_ions.gro'
    mdp=Path(__file__).resolve().parent/'mdp'
    for stage in ['em','nvt','npt','production']:
        args=[gmx,'grompp','-f',str(mdp/f'{stage}.mdp'),'-c',str(previous),'-p',str(base/'topol.top'),'-o',str(o/f'{stage}.tpr'),'-po',str(o/f'{stage}_processed.mdp')]
        if stage in ['nvt','npt']:args+=['-r',str(base/'solvated_ions.gro')]
        if stage in ['npt','production']:args+=['-t',str(o/f'{"nvt" if stage=="npt" else "npt"}.cpt')]
        steps.append(command(*args));steps.append(command(gmx,'mdrun','-deffnm',o/stage,'-nt',nt))
        previous=o/f'{stage}.gro';inputs.append(str(mdp/f'{stage}.mdp'))
    steps.append(command(gmx,'energy','-f',o/'production.edr','-o',o/'temperature.xvg',stdin='Temperature\n0\n'))
    steps.append(command(gmx,'energy','-f',o/'production.edr','-o',o/'density.xvg',stdin='Density\n0\n'))
    return steps,inputs
if __name__=='__main__':
    a,c=load()
    if a.execute and not c.get('preparation_reviewed'):raise ValueError('Review topology, parameters, restraints and system before setting preparation_reviewed=true')
    steps,inputs=build(c);execute(steps,c,inputs,a.execute,c['out'])
