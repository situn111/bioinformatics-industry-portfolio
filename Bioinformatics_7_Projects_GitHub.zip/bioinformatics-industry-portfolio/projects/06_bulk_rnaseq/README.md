# Bulk RNA-seq differential expression

**Area:** Transcriptomics / target discovery  
**Status:** implemented research/portfolio starter; external-tool runs not end-to-end validated in this delivery.

## Pipeline

Paired FASTQ → fastp → STAR → featureCounts fragments → DESeq2 batch-adjusted contrast → QC plots

## Question this project addresses

Which genes differ between replicated conditions after accounting for batch?

## Setup and run

Run all commands from the repository root on Linux or Ubuntu under WSL2.

```bash
conda env create -f projects/06_bulk_rnaseq/environment.yml
conda activate 06_bulk_rnaseq
python projects/06_bulk_rnaseq/pipeline.py --config projects/06_bulk_rnaseq/config.example.json
# Edit a COPY of config.example.json; inspect the plan before execution.
python projects/06_bulk_rnaseq/pipeline.py --config path/to/your_config.json --execute
```

Without `--execute`, the script produces a plan and does not launch scientific tools. A plan is not input-file or scientific validation. Config paths are resolved relative to your current directory (use the repository root). Execution requires a new/empty output directory. There is no silent resume; use a new run ID after fixing failures.

The environment files pin selected major/minor versions as baseline constraints. They are not solved lockfiles and were not installed here. Resolve them on your platform, run validation, then capture exact package builds with `tools/environment_snapshot.sh`.

## Inputs and preparation

Edit the CSV with `sample,r1,r2,condition,batch`. Samples must be independent biological replicates, with at least three per condition in this example. Use a STAR reference index and GTF from the same assembly/release. Generate the index externally with a suitable `--sjdbOverhang` for read length. Confirm library strandedness experimentally or with a validated inference tool: featureCounts 0=unstranded, 1=forward, 2=reverse.

The code counts paired fragments with `-p --countReadPairs`, requires both ends mapped, and excludes chimeric pairs. Confirm that policy matches the assay. The design is `~ batch + condition` when batch adjustment is enabled; the R script rejects a rank-deficient/confounded design. Example CSV is metadata only; FASTQ files are not supplied.

## Outputs

STAR logs and BAMs; featureCounts table; differential_expression.csv; normalized_counts.csv; DESeq2 object; PCA/MA/histogram PDF; MultiQC; R session info

## Validation and interpretation

Inspect library complexity, read quality, mapping and assignment rates, strandedness, gene-body bias, sample correlations/PCA and batch confounding. Confirm sample labels and replicate independence. Report FDR-adjusted p-values with effect sizes; distinguish NA results and prefiltering. The reported log2 fold changes are unshrunken DESeq2 estimates.

Do not feed TPM/FPKM into DESeq2. Do not treat technical replicates as biological replicates. Pathway enrichment is intentionally not automated without a reviewed gene universe, species/ID mapping and gene-set version. Differential expression is association, not proof of a drug target or causal mechanism.

## Resource planning

8–16 CPU cores and about 32–64+ GB RAM for a human STAR genome; disk scales with sample count. Sequential sample execution trades speed for simplicity.

## Reproducibility record

Keep the edited configuration, input checksums, reference/database versions, exact environment export, command logs, code commit, QC decisions and final reports together. Commands for checksum generation are in `tools/hash_inputs.py`. See `docs/VALIDATION.md` and `docs/TEST_REPORT.md` for what was and was not tested.

## Primary documentation

- https://github.com/alexdobin/STAR
- https://subread.sourceforge.net/featureCounts.html
- https://www.bioconductor.org/packages/release/bioc/vignettes/DESeq2/inst/doc/DESeq2.html
