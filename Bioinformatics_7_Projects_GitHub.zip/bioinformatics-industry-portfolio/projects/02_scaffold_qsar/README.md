# Scaffold-aware potency prediction

**Area:** Drug discovery / machine learning  
**Status:** implemented research/portfolio starter; external-tool runs not end-to-end validated in this delivery.

## Pipeline

Curated single-assay pIC50 → Morgan fingerprints → scaffold holdout → training-only group CV → held-out evaluation

## Question this project addresses

Can a molecular model generalize to held-out chemical scaffolds within one assay?

## Setup and run

Run all commands from the repository root on Linux or Ubuntu under WSL2.

```bash
conda env create -f projects/02_scaffold_qsar/environment.yml
conda activate 02_scaffold_qsar
python projects/02_scaffold_qsar/pipeline.py --config projects/02_scaffold_qsar/config.example.json
# Edit a COPY of config.example.json; inspect the plan before execution.
python projects/02_scaffold_qsar/pipeline.py --config path/to/your_config.json --execute
```

Without `--execute`, the script produces a plan and does not launch scientific tools. A plan is not input-file or scientific validation. Config paths are resolved relative to your current directory (use the repository root). Execution requires a new/empty output directory. There is no silent resume; use a new run ID after fixing failures.

The environment files pin selected major/minor versions as baseline constraints. They are not solved lockfiles and were not installed here. Resolve them on your platform, run validation, then capture exact package builds with `tools/environment_snapshot.sh`.

## Inputs and preparation

Input CSV columns: `id,smiles,pIC50,target,assay_id`. Use exact quantitative IC50 values from one harmonized assay and one target. Convert molar concentration to `pIC50 = -log10(IC50 in M)`; for nM, `pIC50 = 9 - log10(IC50 in nM)`. Do not treat censored values such as >10 µM as exact points. Do not mix IC50, Ki, Kd and percent inhibition.

Resolve salts, duplicate structures, conflicting measurements, unspecified stereochemistry and assay metadata before training. The supplied data has random synthetic labels and is ONLY a plumbing demo. Set `synthetic_demo` to false only when supplying real curated data.

## Outputs

model.joblib; metrics.json; heldout_predictions.csv; split_manifest.csv; run_config.json

## Validation and interpretation

Evaluate scaffold-disjoint RMSE, MAE and R² against the mean predictor; report confidence intervals from scaffold-level resampling and an independent temporal/external test set before making performance claims. This baseline uses fixed hyperparameters; any tuning must stay inside training-only grouped/nested CV. Do not select models based on the held-out set.

The code rejects duplicates and requires at least eight scaffold groups. This is a software guard, not proof of statistical power. All acyclic compounds are conservatively placed in one group. Similarity to training compounds is an applicability diagnostic, not a calibrated uncertainty estimate. Joblib files use pickle: load only trusted artifacts. No deployment service or prospective screening inference is included.

## Resource planning

4–8 CPU cores, 4–16 GB RAM for modest datasets; increase memory for large fingerprint matrices.

## Reproducibility record

Keep the edited configuration, input checksums, reference/database versions, exact environment export, command logs, code commit, QC decisions and final reports together. Commands for checksum generation are in `tools/hash_inputs.py`. See `docs/VALIDATION.md` and `docs/TEST_REPORT.md` for what was and was not tested.

## Primary documentation

- https://www.rdkit.org/docs/source/rdkit.Chem.Scaffolds.MurckoScaffold.html
- https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.GroupShuffleSplit.html
- https://scikit-learn.org/stable/modules/cross_validation.html
