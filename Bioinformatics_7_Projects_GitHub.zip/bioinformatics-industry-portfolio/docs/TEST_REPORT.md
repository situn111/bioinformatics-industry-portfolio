# Delivery test report

Date: 2026-10-19

## Executed and passed

- Python compilation for common utilities, all seven pipelines, tools and tests.
- All seven workflow/config command previews (no scientific tools invoked).
- Nine unit/contract tests: unsafe identifiers, literal subprocess arguments, stop-on-error and failure manifests, output preservation, missing inputs, scaffold-disjoint holdout, somatic artifact filters, BQSR-before-calling order, and paired-fragment RNA counts.
- Bash syntax checks for environment snapshot, VEP annotation, SLURM example and MD analysis.

Execution environment: Python 3.12.14, NumPy 2.3.5, scikit-learn 1.8.0. These are the test runtime's versions, not proof that the project conda environments resolve.

## Not executed here

- Conda environment solving/installation or exact-build lock generation.
- Receptor/ligand preparation or Vina docking.
- RDKit end-to-end QSAR training, even on the bundled synthetic labels.
- GROMACS system preparation, simulation or trajectory analysis.
- FASTQ alignment, GATK germline/somatic calling or VEP annotation.
- STAR, featureCounts, R/DESeq2 or MultiQC runs (R not available).
- Scanpy/Scrublet single-cell analysis.
- SLURM scheduling or GitHub-hosted CI itself.
- Biological benchmark, clinical validation, runtime/memory benchmark or production certification.

## How to reproduce code-level checks

```bash
python -m pip install numpy==1.26.4 scikit-learn==1.5.2
python -m unittest discover -s tests -v
make plans
```

Passing these checks establishes limited code-level behavior, not scientific correctness for your dataset. Follow each project README and VALIDATION.md before using results in a decision.
