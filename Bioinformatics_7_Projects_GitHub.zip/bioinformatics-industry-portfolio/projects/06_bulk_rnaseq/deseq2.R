suppressPackageStartupMessages(library(DESeq2))
a <- commandArgs(trailingOnly=TRUE)
stopifnot(length(a)==6)
fc <- read.delim(a[1],comment.char="#",check.names=FALSE)
meta <- read.csv(a[2],stringsAsFactors=FALSE)
stopifnot(!anyDuplicated(meta$sample))
mat <- as.matrix(fc[,7:ncol(fc),drop=FALSE]); storage.mode(mat)<-"integer"
ids <- sub("\\.Aligned.sortedByCoord.out.bam$","",basename(colnames(mat)))
stopifnot(setequal(ids,meta$sample),!anyDuplicated(fc$Geneid))
meta <- meta[match(ids,meta$sample),,drop=FALSE]
rownames(meta)<-meta$sample;colnames(mat)<-ids;rownames(mat)<-fc$Geneid
stopifnot(all(mat>=0),identical(colnames(mat),rownames(meta)))
meta$condition<-relevel(factor(meta$condition),ref=a[3])
meta$batch<-factor(meta$batch)
design_formula<-if(a[5]=="true") ~ batch + condition else ~ condition
mm<-model.matrix(design_formula,meta)
if(qr(mm)$rank<ncol(mm))stop("Batch and condition are confounded; design is not full rank")
dds<-DESeqDataSetFromMatrix(mat,meta,design=design_formula)
dds<-dds[rowSums(counts(dds)>=10)>=3,]
if(nrow(dds)<10)stop("Too few genes after low-count filtering")
dds<-DESeq(dds)
r<-results(dds,contrast=c("condition",a[4],a[3]),alpha=0.05)
out<-a[6]
write.csv(as.data.frame(r),file.path(out,"differential_expression.csv"))
write.csv(counts(dds,normalized=TRUE),file.path(out,"normalized_counts.csv"))
vsd<-varianceStabilizingTransformation(dds,blind=FALSE)
pdf(file.path(out,"qc_plots.pdf"))
print(plotPCA(vsd,intgroup=c("condition","batch")))
plotMA(r,ylim=c(-5,5));hist(r$pvalue,main="P value distribution",xlab="P value")
dev.off()
saveRDS(dds,file.path(out,"deseq2.rds"))
writeLines(capture.output(sessionInfo()),file.path(out,"R_sessionInfo.txt"))
