#!/usr/bin/env bash
set -euo pipefail
# Requires a separately installed Ensembl VEP plus matching offline cache.
input=${1:?Usage: annotate_vep.sh input.vcf.gz output.vcf.gz reference.fa cache_dir cache_version}
output=${2:?Provide a new output filename}
fasta=${3:?Provide reference FASTA}
cache=${4:?Provide cache directory}
version=${5:?Provide cache release matching installed VEP}
[[ ! -e "$output" ]] || { echo "Output exists: $output" >&2; exit 1; }
vep --input_file "$input" --output_file "$output" --vcf --compress_output bgzip \
  --offline --cache --dir_cache "$cache" --cache_version "$version" \
  --species homo_sapiens --assembly GRCh38 --fasta "$fasta" \
  --symbol --canonical --hgvs --numbers --fork 4
# GRCh38/human is explicit here; edit together with reference/cache for other settings.
# Consequence annotation is not clinical interpretation or drug actionability.
