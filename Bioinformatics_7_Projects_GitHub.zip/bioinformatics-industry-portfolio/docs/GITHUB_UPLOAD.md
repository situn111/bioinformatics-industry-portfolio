# Upload this repository to GitHub

The delivered ZIP is a transport container. **Extract it first.** Upload the files and folders inside `bioinformatics-industry-portfolio`, so `README.md` is at the repository root. Uploading the ZIP alone will not expose seven browsable projects or run GitHub Actions.

## Recommended: Git

Create an empty GitHub repository called `bioinformatics-industry-portfolio` under your own account (do not initialize another README). Then, inside the extracted folder:

```bash
git init
git add .
git status
# Review the staged file list for private data before committing.
git commit -m "Add seven computational biology portfolio pipelines"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/bioinformatics-industry-portfolio.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your real GitHub username. Authenticate with GitHub's supported login/token flow; never paste a token into source code or a public URL.

## Browser alternative

Create the repository, choose **Add file → Upload files**, and upload the extracted contents. Make sure hidden `.github` and `.gitignore` are included. For numerous files or upload limits, use Git or GitHub Desktop.

## After upload

- Review the rendered root README and each project README.
- Check the Actions tab for CI results.
- Update maintainer/contact details if desired.
- Add genuine validation reports and public-data analyses before describing projects as independently completed studies.
- Add this repository to LinkedIn Featured and your portfolio website when ready.
- Put large datasets and model artifacts in an appropriate data/release store, not regular Git history.

Suggested description: Seven research workflow starters for virtual screening, QSAR, molecular dynamics, WGS, somatic variants, bulk RNA-seq and single-cell RNA-seq.
