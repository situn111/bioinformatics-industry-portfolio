import unittest,tempfile,json,sys,subprocess,importlib.util
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from common.runner import identifier,execute,command
ROOT=Path(__file__).resolve().parents[1]
def module(slug):
    spec=importlib.util.spec_from_file_location(slug,ROOT/'projects'/slug/'pipeline.py')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod
class RunnerTests(unittest.TestCase):
    def test_reject_unsafe_identifiers(self):
        for value in ['../sample','x; rm -rf','two samples','','a/b']:
            with self.assertRaises(ValueError):identifier(value)
        self.assertEqual(identifier('Sample_01'),'Sample_01')
    def test_argument_not_executed_as_shell(self):
        with tempfile.TemporaryDirectory() as t:
            out=Path(t)/'run';target=Path(t)/'INJECTED'
            payload='; touch '+str(target)
            execute([command(sys.executable,'-c','import sys; print(sys.argv[1])',payload)],{},[],True,out)
            self.assertFalse(target.exists())
            self.assertIn(payload,next(out.glob('01_*')).read_text())
    def test_failure_stops_and_records(self):
        with tempfile.TemporaryDirectory() as t:
            out=Path(t)/'run';marker=Path(t)/'should_not_exist'
            steps=[command(sys.executable,'-c','raise SystemExit(7)'),command(sys.executable,'-c',f'open({str(marker)!r},"w").close()')]
            with self.assertRaises(subprocess.CalledProcessError):execute(steps,{},[],True,out)
            self.assertFalse(marker.exists())
            self.assertEqual(json.loads((out/'run_manifest.json').read_text())['status'],'failed')
    def test_existing_results_not_overwritten(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'important.txt';p.write_text('preserve')
            with self.assertRaises(ValueError):execute([],{},[],True,t)
            self.assertEqual(p.read_text(),'preserve')
    def test_missing_input_fails_before_output(self):
        with tempfile.TemporaryDirectory() as t:
            out=Path(t)/'run'
            with self.assertRaises(ValueError):execute([],{},[str(Path(t)/'missing')],True,out)
            self.assertFalse(out.exists())
class ScientificContractTests(unittest.TestCase):
    def test_scaffold_holdout_no_overlap(self):
        m=module('02_scaffold_qsar');groups=[f'group{i//5}' for i in range(60)]
        tr,te=m.scaffold_split(groups,42)
        self.assertFalse(set(groups[i] for i in tr)&set(groups[i] for i in te))
        self.assertEqual(len(tr)+len(te),len(groups))
    def test_somatic_filters_have_bias_and_contamination(self):
        m=module('05_somatic_variants');c=json.loads((ROOT/'projects/05_somatic_variants/config.example.json').read_text())
        steps,_=m.build(c);f=next(s['argv'] for s in steps if 'FilterMutectCalls' in s['argv'])
        for arg in ['--contamination-table','--tumor-segmentation','--ob-priors']:self.assertIn(arg,f)
    def test_germline_bqsr_precedes_calling(self):
        m=module('04_germline_wgs');c=json.loads((ROOT/'projects/04_germline_wgs/config.example.json').read_text())
        steps,_=m.build(c);args=[s['argv'] for s in steps]
        at=lambda name:next(i for i,v in enumerate(args) if name in v)
        self.assertLess(at('BaseRecalibrator'),at('ApplyBQSR'));self.assertLess(at('ApplyBQSR'),at('HaplotypeCaller'))
        hc=args[at('HaplotypeCaller')];self.assertIn('GVCF',hc)
    def test_rna_counts_fragments(self):
        m=module('06_bulk_rnaseq');c=json.loads((ROOT/'projects/06_bulk_rnaseq/config.example.json').read_text())
        steps,_=m.build(c);fc=next(s['argv'] for s in steps if s['argv'][0]=='featureCounts')
        self.assertIn('-p',fc);self.assertIn('--countReadPairs',fc)
if __name__=='__main__':unittest.main()
