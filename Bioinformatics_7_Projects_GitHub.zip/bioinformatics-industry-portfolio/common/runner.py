"""Shell-free, fail-fast sequential workflow execution with provenance."""
import argparse, datetime, hashlib, json, os, re, shutil, subprocess, sys
from pathlib import Path

def identifier(value):
    if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,63}',value):
        raise ValueError(f'Unsafe identifier: {value!r}')
    return value

def load():
    p=argparse.ArgumentParser()
    p.add_argument('--config',required=True)
    p.add_argument('--execute',action='store_true',help='Without this flag, print a command plan only.')
    a=p.parse_args(); path=Path(a.config).resolve()
    data=json.loads(path.read_text())
    if not isinstance(data,dict): raise ValueError('Config must be a JSON object')
    for key in ('threads','cpu','exhaustiveness','poses','ploidy'):
        if key in data and (not isinstance(data[key],int) or isinstance(data[key],bool) or data[key]<1):
            raise ValueError(f'{key} must be a positive integer')
    return a,data

def file_input(value):
    p=Path(value).expanduser().resolve()
    if not p.is_file(): raise ValueError(f'Missing input file: {p}')
    return p

def output_dir(value):
    p=Path(value).resolve()
    if p.exists() and any(p.iterdir()): raise ValueError(f'Output directory must be empty: {p}')
    p.mkdir(parents=True,exist_ok=True)
    return p

def command(*args,stdout=None,stdin=None):
    d={'argv':[str(x) for x in args]}
    if stdout is not None:d['stdout']=str(stdout)
    if stdin is not None:d['stdin']=stdin
    return d

def execute(steps,config,inputs,do_execute,out):
    """Paths in configs are relative to repository root, not config location.
    No shell expansion, silent resume, overwrite, or implicit data downloads.
    """
    if not do_execute:
        print(json.dumps({'mode':'PLAN_ONLY','out':str(out),'steps':steps},indent=2));return
    paths=[file_input(x) for x in inputs]
    for s in steps:
        if shutil.which(s['argv'][0]) is None: raise RuntimeError('Missing executable: '+s['argv'][0])
    directory=output_dir(out)
    manifest={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'python':sys.version,'config':config,'steps':steps,'status':'running',
              'inputs':[{'path':str(p),'bytes':p.stat().st_size,'mtime_ns':p.stat().st_mtime_ns} for p in paths]}
    # Large FASTQ/BAM hashing is intentionally separate (tools/hash_inputs.py).
    manifest_path=directory/'run_manifest.json'
    def save(): manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
    save()
    try:
        for i,s in enumerate(steps,1):
            log=directory/f'{i:02d}_{Path(s["argv"][0]).name}.log'
            with log.open('w') as err:
                stream=open(s['stdout'],'w') if s.get('stdout') else err
                try:
                    subprocess.run(s['argv'],input=s.get('stdin'),text=True,
                                   stdout=stream,stderr=err,check=True)
                finally:
                    if stream is not err:stream.close()
            manifest['completed_steps']=i;save()
        manifest['status']='completed'
    except Exception as e:
        manifest['status']='failed';manifest['error']=str(e);raise
    finally:
        manifest['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
