# Structure-based virtual screening

**Area:** Drug discovery / computational chemistry  
**Status:** implemented research/portfolio starter; external-tool runs not end-to-end validated in this delivery.

## Pipeline

Prepared receptor + curated SMILES → 3D ligand → PDBQT → Vina docking → ranked poses

## Question this project addresses

Which curated compounds generate plausible poses in a specified target pocket?

## Setup and run

Run all commands from the repository root on Linux or Ubuntu under WSL2.

```bash
conda env create -f projects/01_virtual_screening/environment.yml
conda activate 01_virtual_screening
python projects/01_virtual_screening/pipeline.py --config projects/01_virtual_screening/config.example.json
# Edit a COPY of config.example.json; inspect the plan before execution.
python projects/01_virtual_screening/pipeline.py --config path/to/your_config.json --execute
```

Without `--execute`, the script produces a plan and does not launch scientific tools. A plan is not input-file or scientific validation. Config paths are resolved relative to your current directory (use the repository root). Execution requires a new/empty output directory. There is no silent resume; use a new run ID after fixing failures.

The environment files pin selected major/minor versions as baseline constraints. They are not solved lockfiles and were not installed here. Resolve them on your platform, run validation, then capture exact package builds with `tools/environment_snapshot.sh`.

## Inputs and preparation

Provide a protein receptor PDBQT prepared for the intended biological assembly. Inspect missing residues, cofactors, metals, disulfides and crystallographic waters. Establish protonation and ligand stereochemistry at the assay pH. The code does not guess these choices.

The included caffeine/aspirin SMILES are software-format examples, not proposed hits. Replace them with licensed, curated compounds. Set the box center and size from the experimental binding site, then set `box_validated` to true. All box coordinates are in angstroms. Set an explicit output directory for each run.

## Outputs

ranking.csv; per-ligand PDBQT poses; failures.json; run_config.json

## Validation and interpretation

Redock a co-crystallized ligand, evaluate symmetry-aware heavy-atom RMSD, compare known actives and matched decoys, inspect clashes and key interactions, and repeat stochastic docking across seeds. A nominal redocking RMSD near 2 Å is a common diagnostic, not an automatic pass for every system. Vina scores are not experimental affinity, selectivity, or efficacy. Cross-target score comparisons are not a calibrated ranking.

Receptor preparation, tautomer/protonation enumeration, pose visualization and experimental validation are external responsibilities. Any ligand failure makes the run fail after writing partial outputs; do not report partial rankings as complete.

## Resource planning

4–16 CPU cores; often 4–16 GB RAM. Runtime depends on ligand count, torsions, box and exhaustiveness.

## Reproducibility record

Keep the edited configuration, input checksums, reference/database versions, exact environment export, command logs, code commit, QC decisions and final reports together. Commands for checksum generation are in `tools/hash_inputs.py`. See `docs/VALIDATION.md` and `docs/TEST_REPORT.md` for what was and was not tested.

## Primary documentation

- https://autodock-vina.readthedocs.io/en/latest/docking_python.html
- https://meeko.readthedocs.io/en/release/
- https://www.rdkit.org/docs/GettingStartedInPython.html
