import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from common.runner import load,execute,command,identifier

def build(c):

    o=Path(c['out']);ref=c['reference'];normal=identifier(c['normal_sample'])
    inputs=[ref,ref+'.fai',str(Path(ref).with_suffix('.dict')),c['tumor_bam'],c['normal_bam'],c['germline_resource'],c['panel_of_normals'],c['common_sites']]
    s=[command('gatk','ValidateSamFile','-I',c['tumor_bam'],'-MODE','SUMMARY'),command('gatk','ValidateSamFile','-I',c['normal_bam'],'-MODE','SUMMARY'),
       command('gatk','Mutect2','-R',ref,'-I',c['tumor_bam'],'-I',c['normal_bam'],'-normal',normal,'--germline-resource',c['germline_resource'],'--panel-of-normals',c['panel_of_normals'],'--f1r2-tar-gz',o/'f1r2.tar.gz','-O',o/'unfiltered.vcf.gz'),
       command('gatk','LearnReadOrientationModel','-I',o/'f1r2.tar.gz','-O',o/'orientation.tar.gz')]
    for label in ['tumor','normal']:
        s.append(command('gatk','GetPileupSummaries','-I',c[label+'_bam'],'-V',c['common_sites'],'-L',c['common_sites'],'-O',o/f'{label}.pileups.table'))
    s += [command('gatk','CalculateContamination','-I',o/'tumor.pileups.table','-matched',o/'normal.pileups.table','-O',o/'contamination.table','--tumor-segmentation',o/'segments.table'),
          command('gatk','FilterMutectCalls','-R',ref,'-V',o/'unfiltered.vcf.gz','--contamination-table',o/'contamination.table','--tumor-segmentation',o/'segments.table','--ob-priors',o/'orientation.tar.gz','-O',o/'filtered.vcf.gz'),
          command('bcftools','view','-f','PASS','-Oz','-o',o/'pass.vcf.gz',o/'filtered.vcf.gz'),command('bcftools','index','-t',o/'pass.vcf.gz'),
          command('bcftools','stats',o/'pass.vcf.gz',stdout=o/'variant_stats.txt')]
    return s,inputs

if __name__=='__main__':
    a,c=load();steps,inputs=build(c);execute(steps,c,inputs,a.execute,c['out'])
