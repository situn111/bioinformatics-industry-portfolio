# Finding evaluation data

No human FASTQs, patient metadata, compound bioactivity claims or prepared receptor complexes are bundled. No script silently downloads a large reference.

| Project | Candidate source | What to record |
|---|---|---|
| Docking | RCSB PDB, https://www.rcsb.org/ | PDB ID, assembly, ligand, resolution, preparation and site definition |
| QSAR | ChEMBL, https://www.ebi.ac.uk/chembl/ | Release, target/assay IDs, endpoint, units, qualifiers, licensing and curation |
| MD | Prepared experimental complex | Force fields, versions, ligand charge method, topology, water/ions and atom ordering |
| Germline | GIAB, https://www.nist.gov/programs-projects/genome-bottle | Sample, reads, reference, truth VCF, confident BED and benchmark version |
| Somatic | SEQC2 reference materials / public tumour-normal benchmarks | Tumour/normal identities, mixing fraction, reference and truth regions |
| Bulk RNA | GEO, https://www.ncbi.nlm.nih.gov/geo/ or ENA, https://www.ebi.ac.uk/ena/browser/ | Accession, biological replication, conditions, batch, library type and read layout |
| Single-cell | 10x public datasets, https://www.10xgenomics.com/datasets | Accession, chemistry, count-generation version, donor/sample and tissue |

These are source landing pages, not frozen datasets. Select and document the actual accessions before analysis. Keep build-specific FASTA, GTF, VCF, cache and indexes consistent. Never infer availability or consent from an accession alone.
