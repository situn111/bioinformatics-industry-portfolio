# Analysis report

## Scientific question and intended use
## Dataset accession, permissions and inclusion criteria
## Input and reference versions / checksums
## Software environment and Git commit
## Pipeline configuration and rationale
## QC and exclusions
## Benchmark and independent validation
## Results with uncertainty
## Interpretation and limitations
## Reproduction command
## Reviewer and date

Attach logs, manifests and plots; never invent a metric or claim a test was executed when it was only planned.
