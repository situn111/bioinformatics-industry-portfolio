# Reference preparation examples

Run outside the analysis output directory, after verifying assembly names and licenses. Resources are not downloaded automatically.

```bash
# DNA reference (BWA classic, not bwa-mem2)
bwa index data/reference/GRCh38.fa
samtools faidx data/reference/GRCh38.fa
gatk CreateSequenceDictionary -R data/reference/GRCh38.fa -O data/reference/GRCh38.dict

# Index bgzip-compressed VCF resources; regular gzip is not sufficient.
tabix -p vcf data/reference/dbsnp.vcf.gz

# STAR: example for 150-base reads; sjdbOverhang is read length minus one.
mkdir -p data/reference/star_index
STAR --runMode genomeGenerate --runThreadN 8 \
  --genomeDir data/reference/star_index \
  --genomeFastaFiles data/reference/GRCh38.fa \
  --sjdbGTFfile data/reference/genes.gtf --sjdbOverhang 149
```

Use the appropriate project environment. `tabix` is supplied through HTSlib packages in many environments; install it explicitly if missing. Recheck contig names and FASTA sequence identity, not merely the label GRCh38. Do not mix reference releases or use a VEP cache from an incompatible assembly/release. Store source accession, release, checksum and generation commands with each reference set.
