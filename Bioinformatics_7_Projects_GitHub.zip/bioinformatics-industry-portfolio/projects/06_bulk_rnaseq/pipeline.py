import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from common.runner import load,execute,command,identifier

def build(c):

    import csv
    o=Path(c['out']);t=str(c['threads']);s=[];bams=[];inputs=[c['samples_csv'],c['gtf']]
    with open(c['samples_csv'],newline='') as f:
        rows=list(csv.DictReader(f))
    ids=[identifier(r['sample']) for r in rows]
    if len(ids)!=len(set(ids)):raise ValueError('Duplicate sample IDs')
    if c['strandedness'] not in [0,1,2]:raise ValueError('strandedness must be 0, 1 or 2')
    conditions={r['condition'] for r in rows}
    if conditions!={c['control'],c['treatment']}:raise ValueError('Exactly the configured control and treatment groups required')
    if any(sum(r['condition']==g for r in rows)<3 for g in conditions):raise ValueError('Use at least three independent biological replicates per group')
    inputs.append(str(Path(c['star_index'])/'Genome'))
    for r in rows:
        sample=r['sample'];inputs += [r['r1'],r['r2']]
        r1=o/f'{sample}.R1.fq.gz';r2=o/f'{sample}.R2.fq.gz';prefix=str(o/f'{sample}.')
        s.append(command('fastp','-i',r['r1'],'-I',r['r2'],'-o',r1,'-O',r2,'--thread',t,'--detect_adapter_for_pe','--json',o/f'{sample}.fastp.json','--html',o/f'{sample}.fastp.html'))
        s.append(command('STAR','--runThreadN',t,'--genomeDir',c['star_index'],'--readFilesIn',r1,r2,'--readFilesCommand','zcat','--outFileNamePrefix',prefix,'--outSAMtype','BAM','SortedByCoordinate','--twopassMode','Basic'))
        bam=prefix+'Aligned.sortedByCoord.out.bam';bams.append(bam);s.append(command('samtools','index',bam))
    s.append(command('featureCounts','-T',t,'-p','--countReadPairs','-B','-C','-s',c['strandedness'],'-t','exon','-g','gene_id','-a',c['gtf'],'-o',o/'counts.txt',*bams))
    s.append(command('Rscript',Path(__file__).resolve().parent/'deseq2.R',o/'counts.txt',c['samples_csv'],c['control'],c['treatment'],str(c['batch_adjust']).lower(),o))
    s.append(command('multiqc',o,'-o',o/'multiqc'))
    return s,inputs

if __name__=='__main__':
    a,c=load();steps,inputs=build(c);execute(steps,c,inputs,a.execute,c['out'])
