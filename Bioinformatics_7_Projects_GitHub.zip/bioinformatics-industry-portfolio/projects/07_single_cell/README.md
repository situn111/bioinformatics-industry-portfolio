# Single-cell RNA-seq exploration

**Area:** Single-cell genomics / cell-state discovery  
**Status:** implemented research/portfolio starter; external-tool runs not end-to-end validated in this delivery.

## Pipeline

Raw 10x counts → per-sample QC and doublets → batch-aware HVGs → PCA → neighbors → UMAP/Leiden → exploratory markers

## Question this project addresses

What cell populations and transcriptional states are suggested by count data?

## Setup and run

Run all commands from the repository root on Linux or Ubuntu under WSL2.

```bash
conda env create -f projects/07_single_cell/environment.yml
conda activate 07_single_cell
python projects/07_single_cell/pipeline.py --config projects/07_single_cell/config.example.json
# Edit a COPY of config.example.json; inspect the plan before execution.
python projects/07_single_cell/pipeline.py --config path/to/your_config.json --execute
```

Without `--execute`, the script produces a plan and does not launch scientific tools. A plan is not input-file or scientific validation. Config paths are resolved relative to your current directory (use the repository root). Execution requires a new/empty output directory. There is no silent resume; use a new run ID after fixing failures.

The environment files pin selected major/minor versions as baseline constraints. They are not solved lockfiles and were not installed here. Resolve them on your platform, run validation, then capture exact package builds with `tools/environment_snapshot.sh`.

## Inputs and preparation

Supply 10x filtered feature-barcode HDF5 files containing raw integer counts, not normalized counts, and metadata `sample,counts_h5,condition`. The mitochondrial prefix is species-specific (`MT-` in the human example; often `mt-` in mouse); validate that gene identifiers are symbols rather than Ensembl IDs.

Tune mitochondrial, gene-count and doublet thresholds for tissue, assay and loading. QC and Scrublet run separately by sample. At least 100 retained cells per sample is a software guard only. The code preserves counts in a layer and log-normalized full genes in `.raw`, selects HVGs with sample information, then clusters an unintegrated PCA neighborhood.

## Outputs

sample_qc.csv; processed.h5ad; UMAP PNG; exploratory_markers.csv; run_config.json

## Validation and interpretation

Inspect sample mixing, cell quality, doublet calls, expected marker panels and robustness to resolution/QC parameters. Batch-aware HVG selection is not batch correction. If batch dominates, evaluate a suitable integration method without removing genuine biological variation, and compare unintegrated results.

Marker testing is exploratory and cell-level; it is not a replicated case-control differential-expression analysis. For condition inference, annotate cell types and aggregate raw counts by biological replicate and cell type for pseudobulk modelling. The two-sample example has no replicated condition inference. Cell type names, CNV-based malignancy calls and drug-response predictions are not assigned automatically.

## Resource planning

4–16 CPU cores and 16–64+ GB RAM depending on cells/genes; memory may rise in PCA and marker testing.

## Reproducibility record

Keep the edited configuration, input checksums, reference/database versions, exact environment export, command logs, code commit, QC decisions and final reports together. Commands for checksum generation are in `tools/hash_inputs.py`. See `docs/VALIDATION.md` and `docs/TEST_REPORT.md` for what was and was not tested.

## Primary documentation

- https://scanpy.readthedocs.io/en/stable/tutorials/basics/clustering.html
- https://scanpy.readthedocs.io/en/stable/api/generated/scanpy.pp.scrublet.html
