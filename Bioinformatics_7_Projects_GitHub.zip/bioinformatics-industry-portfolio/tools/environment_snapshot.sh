#!/usr/bin/env bash
set -euo pipefail
# Activate the project environment first. Store this with each experiment.
conda list --explicit > environment-explicit.txt
conda env export --no-builds > environment-resolved.yml
