import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from common.runner import load,execute,command,identifier

def build(c):

    o=Path(c['out']);sample=identifier(c['sample']);ref=c['reference'];t=str(c['threads'])
    rg='@RG\\tID:'+sample+'\\tSM:'+sample+'\\tPL:ILLUMINA\\tLB:'+sample+'\\tPU:'+sample
    inputs=[c['r1'],c['r2'],ref,ref+'.fai',str(Path(ref).with_suffix('.dict'))]+c['known_sites']
    inputs += [ref+x for x in ['.amb','.ann','.bwt','.pac','.sa']]
    if not c['known_sites']:raise ValueError('BQSR requires compatible known-sites resources')
    s=[command('fastp','-i',c['r1'],'-I',c['r2'],'-o',o/'r1.fq.gz','-O',o/'r2.fq.gz','--detect_adapter_for_pe','--thread',t,'--html',o/'fastp.html','--json',o/'fastp.json'),
       command('bwa','mem','-t',t,'-R',rg,ref,o/'r1.fq.gz',o/'r2.fq.gz',stdout=o/'aligned.sam'),
       command('samtools','sort','-@',t,'-o',o/'sorted.bam',o/'aligned.sam'),
       command('gatk','MarkDuplicates','-I',o/'sorted.bam','-O',o/'dedup.bam','-M',o/'duplicates.txt','--CREATE_INDEX','true')]
    s.append(command('gatk','BaseRecalibrator','-R',ref,'-I',o/'dedup.bam',*[v for k in c['known_sites'] for v in ['--known-sites',k]],'-O',o/'recal.table'))
    s += [command('gatk','ApplyBQSR','-R',ref,'-I',o/'dedup.bam','--bqsr-recal-file',o/'recal.table','-O',o/'analysis.bam'),
          command('samtools','index',o/'analysis.bam'),command('samtools','flagstat',o/'analysis.bam',stdout=o/'flagstat.txt'),
          command('gatk','HaplotypeCaller','-R',ref,'-I',o/'analysis.bam','-ERC','GVCF','--sample-ploidy',c['ploidy'],'-O',o/'sample.g.vcf.gz'),
          command('gatk','GenotypeGVCFs','-R',ref,'-V',o/'sample.g.vcf.gz','-O',o/'raw.vcf.gz')]
    for typ,expr in [('SNP',c['snp_filter']),('INDEL',c['indel_filter'])]:
        s += [command('gatk','SelectVariants','-R',ref,'-V',o/'raw.vcf.gz','--select-type-to-include',typ,'-O',o/f'{typ}.vcf.gz'),
              command('gatk','VariantFiltration','-R',ref,'-V',o/f'{typ}.vcf.gz','--filter-name','HARD_FILTER','--filter-expression',expr,'-O',o/f'{typ}.filtered.vcf.gz')]
    s += [command('gatk','MergeVcfs','-I',o/'SNP.filtered.vcf.gz','-I',o/'INDEL.filtered.vcf.gz','-O',o/'filtered.vcf.gz'),
          command('bcftools','view','-f','PASS','-Oz','-o',o/'pass.vcf.gz',o/'filtered.vcf.gz'),
          command('bcftools','index','-t',o/'pass.vcf.gz'),command('bcftools','stats',o/'pass.vcf.gz',stdout=o/'variant_stats.txt')]
    return s,inputs

if __name__=='__main__':
    a,c=load();steps,inputs=build(c);execute(steps,c,inputs,a.execute,c['out'])
