"""Per-sample doublet screening, batch-aware HVG selection and exploratory clusters."""
import sys,json,csv
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from common.runner import load,file_input,output_dir,identifier

def main():
    a,c=load()
    if not a.execute:
        print(json.dumps({'mode':'PLAN_ONLY','workflow':['10x counts per sample','QC','Scrublet per sample','concatenate','normalize log1p','batch-aware HVGs','PCA neighbors UMAP Leiden','exploratory markers'],'config':c},indent=2));return
    import scanpy as sc,anndata as ad,numpy as np,pandas as pd
    from scipy import sparse
    with file_input(c['samples_csv']).open(newline='') as f:
        rows=list(csv.DictReader(f))
    ids=[identifier(r['sample']) for r in rows]
    if len(ids)!=len(set(ids)):raise ValueError('Duplicate sample IDs')
    out=output_dir(c['out']);datasets=[];qc=[]
    sc.settings.figdir=out;sc.settings.n_jobs=int(c['cpu'])
    for r in rows:
        x=sc.read_10x_h5(str(file_input(r['counts_h5'])))
        x.var_names_make_unique();x.obs_names_make_unique()
        values=x.X.data if sparse.issparse(x.X) else x.X.ravel()
        if (values<0).any() or not np.allclose(values,np.round(values)):raise ValueError('Require raw nonnegative integer counts')
        x.var['mt']=x.var_names.str.startswith(c['mito_prefix'])
        sc.pp.calculate_qc_metrics(x,qc_vars=['mt'],percent_top=None,log1p=False,inplace=True)
        before=x.n_obs
        x=x[(x.obs.n_genes_by_counts>=c['min_genes']) & (x.obs.n_genes_by_counts<=c['max_genes']) & (x.obs.pct_counts_mt<c['max_mito_pct'])].copy()
        if x.n_obs<100:raise ValueError('Too few retained cells for this demonstration workflow')
        sc.pp.filter_genes(x,min_cells=3)
        sc.pp.scrublet(x,expected_doublet_rate=c['expected_doublet_rate'],random_state=c['seed'])
        dbl=int(x.obs.predicted_doublet.sum());x=x[~x.obs.predicted_doublet].copy()
        x.obs['sample']=r['sample'];x.obs['condition']=r['condition'];datasets.append(x)
        qc.append(dict(sample=r['sample'],input_cells=before,retained=x.n_obs,removed_doublets=dbl))
    # Inner join retains common measured genes; QC has already been performed per sample.
    x=ad.concat(datasets,join='inner',keys=ids,index_unique='-')
    x.layers['counts']=x.X.copy()
    sc.pp.normalize_total(x,target_sum=1e4);sc.pp.log1p(x);x.raw=x
    sc.pp.highly_variable_genes(x,n_top_genes=min(2000,x.n_vars),batch_key='sample',flavor='seurat')
    x=x[:,x.var.highly_variable].copy()
    n=min(30,x.n_obs-1,x.n_vars-1)
    if n<2:raise ValueError('Too few cells/genes for PCA')
    sc.pp.pca(x,n_comps=n,zero_center=True,random_state=c['seed'])
    sc.pp.neighbors(x,n_neighbors=min(15,x.n_obs-1),n_pcs=n,random_state=c['seed'])
    sc.tl.umap(x,random_state=c['seed'])
    sc.tl.leiden(x,resolution=c['resolution'],random_state=c['seed'],flavor='igraph',n_iterations=2,directed=False)
    if (x.obs.leiden.value_counts()<3).any():raise ValueError('Tiny clusters: review QC and clustering before marker testing')
    sc.tl.rank_genes_groups(x,'leiden',method='wilcoxon',use_raw=True)
    sc.get.rank_genes_groups_df(x,group=None).to_csv(out/'exploratory_markers.csv',index=False)
    pd.DataFrame(qc).to_csv(out/'sample_qc.csv',index=False)
    sc.pl.umap(x,color=['sample','condition','leiden'],show=False,save='_overview.png')
    x.write_h5ad(out/'processed.h5ad',compression='gzip')
    (out/'run_config.json').write_text(json.dumps(c,indent=2))
if __name__=='__main__':main()
