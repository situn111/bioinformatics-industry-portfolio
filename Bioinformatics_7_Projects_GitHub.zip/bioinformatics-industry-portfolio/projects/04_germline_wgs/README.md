# Germline short-variant WGS

**Area:** NGS / DNA sequencing  
**Status:** implemented research/portfolio starter; external-tool runs not end-to-end validated in this delivery.

## Pipeline

Paired FASTQ → fastp → BWA → sort → duplicate marking → BQSR → GVCF → genotype → SNP/indel filtering → PASS VCF

## Question this project addresses

Which germline SNVs and small indels are supported by one short-read genome?

## Setup and run

Run all commands from the repository root on Linux or Ubuntu under WSL2.

```bash
conda env create -f projects/04_germline_wgs/environment.yml
conda activate 04_germline_wgs
python projects/04_germline_wgs/pipeline.py --config projects/04_germline_wgs/config.example.json
# Edit a COPY of config.example.json; inspect the plan before execution.
python projects/04_germline_wgs/pipeline.py --config path/to/your_config.json --execute
```

Without `--execute`, the script produces a plan and does not launch scientific tools. A plan is not input-file or scientific validation. Config paths are resolved relative to your current directory (use the repository root). Execution requires a new/empty output directory. There is no silent resume; use a new run ID after fixing failures.

The environment files pin selected major/minor versions as baseline constraints. They are not solved lockfiles and were not installed here. Resolve them on your platform, run validation, then capture exact package builds with `tools/environment_snapshot.sh`.

## Inputs and preparation

Provide one paired-end Illumina biological sample and a reference FASTA with BWA indices (`bwa index`), `.fai` (`samtools faidx`) and sequence dictionary (`gatk CreateSequenceDictionary`). Supply matching-build known-variant VCFs for BQSR, with tabix indices. Contig names, assembly, reference bases and coordinate convention must agree.

The example assigns one read group per sample and uses diploid calls. Multi-lane/multi-library data needs per-lane read groups with real ID/PU/LB values and merge processing. The simplified whole-genome ploidy assumption is not adequate for sex chromosomes, organelles, aneuploidy or mixed ploidy. Partition appropriate intervals and ploidies before extending.

The pipeline writes a large intermediate SAM for transparent sequential execution. Provision substantial temporary disk; a production streaming/scattered workflow should replace this for throughput.

## Outputs

analysis BAM; duplicate metrics; recalibration table; fastp/flagstat reports; GVCF; raw, filtered and PASS VCFs; variant_stats.txt; run manifest

## Validation and interpretation

Benchmark against Genome in a Bottle with a matching truth VCF and high-confidence BED using hap.py or equivalent. Report SNV/indel precision, recall, F1, coverage strata and difficult regions. Review mapping rate, duplicate rate, contamination, sample identity, coverage and genotype quality.

Example hard filters are starting points, not assay validation. Missing annotation behavior must be reviewed; mixed/complex non-SNP/non-INDEL records are not retained by this example split. Cohort joint genotyping, VQSR, CNV/SV, mitochondrial and clinical interpretation workflows are not included. PASS is a filter label, not clinical pathogenicity. The optional annotation script is shared under `tools/annotate_vep.sh`.

## Resource planning

8–32 CPU cores; roughly 32–64+ GB RAM and hundreds of GB to >1 TB scratch for human WGS. Measure actual requirements.

## Reproducibility record

Keep the edited configuration, input checksums, reference/database versions, exact environment export, command logs, code commit, QC decisions and final reports together. Commands for checksum generation are in `tools/hash_inputs.py`. See `docs/VALIDATION.md` and `docs/TEST_REPORT.md` for what was and was not tested.

## Primary documentation

- https://gatk.broadinstitute.org/hc/en-us/categories/360002302312-Getting-Started
- https://github.com/lh3/bwa
- https://www.htslib.org/doc/samtools.html
- https://github.com/Illumina/hap.py
