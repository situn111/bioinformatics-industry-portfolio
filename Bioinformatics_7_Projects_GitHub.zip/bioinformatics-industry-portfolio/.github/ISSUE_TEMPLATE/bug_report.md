---
name: Bug report
about: Report a reproducible technical failure without private data
---
## Project and commit
## Environment / tool versions
## Sanitized command and configuration
## Expected and observed behavior
## Minimal public/synthetic reproduction
