"""Single-target pIC50 regression with held-out Bemis-Murcko scaffolds."""
import sys,json,csv
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from common.runner import load,file_input,output_dir

def scaffold_split(groups,seed=42):
    import numpy as np
    from sklearn.model_selection import GroupShuffleSplit
    idx=np.arange(len(groups))
    tr,te=next(GroupShuffleSplit(n_splits=1,test_size=.25,random_state=seed).split(idx,groups=groups))
    assert not set(groups[i] for i in tr)&set(groups[i] for i in te)
    return tr,te

def main():
    a,c=load()
    if not a.execute:
        print(json.dumps({'mode':'PLAN_ONLY','workflow':['curated single-assay data','canonical deduplication','Morgan fingerprints','scaffold holdout','group CV','test RMSE MAE R2','applicability similarity'],'config':c},indent=2));return
    import numpy as np,pandas as pd,joblib
    from rdkit import Chem,DataStructs
    from rdkit.Chem.Scaffolds import MurckoScaffold
    from rdkit.Chem import rdFingerprintGenerator
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.dummy import DummyRegressor
    from sklearn.model_selection import GroupKFold,cross_val_predict
    from sklearn.metrics import mean_squared_error,mean_absolute_error,r2_score
    data=pd.read_csv(file_input(c['input_csv']))
    required={'id','smiles','pIC50','target','assay_id'}
    if not required.issubset(data.columns):raise ValueError(f'Require {required}')
    if data.empty or data[list(required)].isna().any().any():raise ValueError('Missing values')
    if data.target.nunique()!=1 or data.assay_id.nunique()!=1:raise ValueError('Use one target and harmonized assay; do not pool incompatible endpoints')
    if data.id.duplicated().any():raise ValueError('Duplicate IDs')
    mols=[Chem.MolFromSmiles(s) for s in data.smiles]
    if any(m is None or len(Chem.GetMolFrags(m))!=1 for m in mols):raise ValueError('Invalid SMILES or mixtures')
    data['canonical']=[Chem.MolToSmiles(m) for m in mols]
    if data.canonical.duplicated().any():raise ValueError('Duplicate structures; curate conflicting activity measurements before training')
    y=pd.to_numeric(data.pIC50).to_numpy(float)
    if not np.isfinite(y).all():raise ValueError('Non-finite pIC50')
    groups=[MurckoScaffold.MurckoScaffoldSmiles(mol=m,includeChirality=False) or 'ACYCLIC' for m in mols]
    if len(set(groups))<8:raise ValueError('At least eight scaffold groups required; this is not a sample-size validation rule')
    gen=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048)
    fps=[gen.GetFingerprint(m) for m in mols];X=np.array([gen.GetFingerprintAsNumPy(m) for m in mols])
    tr,te=scaffold_split(groups,int(c['seed']));g=np.array(groups)
    model=RandomForestRegressor(n_estimators=300,min_samples_leaf=2,random_state=int(c['seed']),n_jobs=int(c['cpu']))
    folds=min(5,len(set(g[tr])))
    oof=cross_val_predict(model,X[tr],y[tr],cv=GroupKFold(folds),groups=g[tr],n_jobs=1)
    model.fit(X[tr],y[tr]);pred=model.predict(X[te]);baseline=DummyRegressor().fit(X[tr],y[tr]).predict(X[te])
    def metrics(a,b):return {'rmse':float(mean_squared_error(a,b)**.5),'mae':float(mean_absolute_error(a,b)),'r2':float(r2_score(a,b))}
    out=output_dir(c['out'])
    report={'cv_training_only':metrics(y[tr],oof),'heldout':metrics(y[te],pred),'mean_baseline':metrics(y[te],baseline),'n_train':len(tr),'n_test':len(te),'synthetic_demo':bool(c.get('synthetic_demo',False))}
    (out/'metrics.json').write_text(json.dumps(report,indent=2))
    result=data.iloc[te].copy();result['prediction']=pred
    result['max_train_tanimoto']=[max(DataStructs.BulkTanimotoSimilarity(fps[i],[fps[j] for j in tr])) for i in te]
    result.to_csv(out/'heldout_predictions.csv',index=False)
    data.assign(scaffold=groups,split=['test' if i in set(te) else 'train' for i in range(len(data))]).to_csv(out/'split_manifest.csv',index=False)
    joblib.dump({'model':model,'radius':2,'fpSize':2048,'training_smiles':data.iloc[tr].canonical.tolist(),'target':data.target.iloc[0],'assay_id':data.assay_id.iloc[0]},out/'model.joblib')
    (out/'run_config.json').write_text(json.dumps(c,indent=2))
if __name__=='__main__':main()
