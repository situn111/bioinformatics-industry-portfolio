#!/usr/bin/env bash
#SBATCH --job-name=bioinfo-run
#SBATCH --cpus-per-task=8
#SBATCH --mem=64G
#SBATCH --time=24:00:00
#SBATCH --output=slurm-%j.log
set -euo pipefail
# Submit from repo root after environment activation, for example:
# conda activate 04_germline_wgs
# sbatch hpc/slurm.example.sh projects/04_germline_wgs/pipeline.py myconfig.json
pipeline=${1:?Provide pipeline.py}
config=${2:?Provide JSON config}
python "$pipeline" --config "$config" --execute
# Ensure config threads <= allocated CPUs. Change memory/time/partition to site policy.
